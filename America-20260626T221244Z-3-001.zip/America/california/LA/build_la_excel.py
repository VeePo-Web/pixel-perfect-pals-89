#!/usr/bin/env python3
"""Build Los Angeles Master SEO Database Excel - matching Alberta structure exactly."""
import pickle, re, math, hashlib
from datetime import date
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

with open('la_locations_final.pkl', 'rb') as f:
    locations = pickle.load(f)

print(f"Building LA Excel with {len(locations)} locations...")
today_str = date.today().strftime('%Y-%m-%d')

HEADER_FILL = PatternFill(start_color='1F4E79', end_color='1F4E79', fill_type='solid')
HEADER_FONT = Font(name='Arial', size=11, bold=True, color='FFFFFF')
COL_HEADER_FILL = PatternFill(start_color='D6E4F0', end_color='D6E4F0', fill_type='solid')
COL_HEADER_FONT = Font(name='Arial', size=10, bold=True)
DATA_FONT = Font(name='Arial', size=10)
HEADER_ALIGN = Alignment(horizontal='center', vertical='top', wrap_text=True)
DATA_ALIGN = Alignment(vertical='top', wrap_text=True)

COL_WIDTHS = {
    'A':12,'B':22,'C':14,'D':22,'E':18,'F':12,
    'G':12,'H':12,'I':14,'J':20,'K':30,'L':14,'M':14,
    'N':14,'O':14,'P':14,'Q':14,'R':14,
    'S':30,'T':50,'U':60,'V':40,'W':30,'X':40,'Y':50,'Z':50,
    'AA':14,'AB':50,'AC':50,'AD':60,
    'AE':80,'AF':100,'AG':40,'AH':50,'AI':60,'AJ':50,'AK':60,'AL':50,'AM':60,
    'AN':14,'AO':20,'AP':14,'AQ':30,
}

CATEGORY_HEADERS = {
    'A': ('CORE IDENTIFICATION', 'F'),
    'G': ('GEOGRAPHIC DATA', 'M'),
    'N': ('POPULATION & PRIORITIZATION', 'R'),
    'S': ('SEO METADATA', 'Z'),
    'AA': ('AI SEO / GEO OPTIMIZATION', 'AD'),
    'AE': ('CONTENT', 'AM'),
    'AN': ('QUALITY CONTROL', 'AQ'),
}

COL_NAMES = [
    'Location_ID','Location_Name','Location_Type','Parent_Municipality','Parent_Region','State',
    'Latitude','Longitude','ZIP_Code_Primary','Google_Maps_Place_ID','Google_Maps_Embed_Code',
    'Distance_From_Downtown_LA_Miles','Distance_From_LAX_Miles',
    'Population_2020_Census','Population_2025_Estimate','SEO_Priority_Score',
    'Search_Volume_Estimate','Competition_Level',
    'URL_Slug','SEO_Title_Template','Meta_Description_Template','H1_Template',
    'Primary_Keyword_Template','Secondary_Keywords_Template','Long_Tail_Keywords_Template','Question_Keywords',
    'Entity_Type','Entity_Description','Conversational_Query_Examples','AI_Answer_Snippet',
    'Short_Description','Long_Description','Local_Facts',
    'FAQ_1_Question','FAQ_1_Answer','FAQ_2_Question','FAQ_2_Answer','FAQ_3_Question','FAQ_3_Answer',
    'Verification_Status','Data_Sources','Last_Updated','Notes',
]

# ============================================================
# LA Location Data for major neighborhoods
# ============================================================
LOCATION_DATA = {
    "Downtown Los Angeles": {
        "landmarks": "Walt Disney Concert Hall, The Broad, Grand Central Market, Crypto.com Arena, L.A. Live, Bradbury Building, Pershing Square, Union Station, Cathedral of Our Lady of the Angels",
        "economy": "financial district, tech startups, entertainment venues, hospitality, arts and culture, government offices, fashion industry, real estate development",
        "character": "the revitalized urban core of Los Angeles — once a ghost town after dark, DTLA has transformed into one of America's most exciting urban neighborhoods with luxury lofts, world-class dining, and a thriving arts scene",
        "features": "Arts District murals and galleries, Grand Central Market food hall, L.A. Live entertainment complex, Historic Core architecture, rooftop bars and restaurants, proximity to Union Station and Metro Rail",
        "pop_note": "~62,000+ residents (fastest-growing neighborhood in LA)",
    },
    "Hollywood": {
        "landmarks": "Hollywood Sign, Walk of Fame, TCL Chinese Theatre, Dolby Theatre (Academy Awards), Capitol Records Building, Hollywood Bowl, Griffith Observatory nearby",
        "economy": "entertainment industry (studios, production companies), tourism, hospitality, nightlife, retail, tech and media startups",
        "character": "the entertainment capital of the world — where dreams are made and stars are born, Hollywood combines its legendary film heritage with a gritty, evolving urban landscape that attracts 10+ million tourists annually",
        "features": "Sunset Strip, Hollywood Boulevard, Hollywood and Highland, Pantages Theatre, Paramount Studios lot, vibrant nightlife, proximity to Griffith Park and the Hollywood Sign",
        "pop_note": "~99,600 residents",
    },
    "Silver Lake": {
        "landmarks": "Silver Lake Reservoir, Sunset Junction, Micheltorena Steps, Silver Lake Meadow, Music Box Steps",
        "economy": "creative industries, independent retail, restaurants and cafes, tech startups, boutique fitness",
        "character": "LA's original hipster neighborhood — a hilly, tree-lined community of creatives, musicians, and young professionals known for its independent spirit, eclectic architecture, and some of the best coffee and food in the city",
        "features": "Silver Lake Reservoir walking path, Sunset Boulevard boutiques, thriving restaurant scene (Sqirl, Night+Market), mid-century modern architecture, stairs walks",
        "pop_note": "~35,800 residents",
    },
    "Echo Park": {
        "landmarks": "Echo Park Lake, Angelus Temple, Echo Park Time Travel Mart, Jensen's Recreation Center, Elysian Park nearby",
        "economy": "creative industries, restaurants, small business, retail, arts",
        "character": "one of LA's most vibrant and diverse neighborhoods — known for its iconic lake with pedal boats and lotus flowers, thriving food scene, and strong community identity that bridges old-school Angeleno culture with new creative energy",
        "features": "Echo Park Lake pedal boats, Sunset Blvd restaurants and bars, proximity to Dodger Stadium, growing culinary scene, historic Victorian homes, diverse cultural mix",
        "pop_note": "~29,200 residents",
    },
    "Venice": {
        "landmarks": "Venice Beach Boardwalk, Muscle Beach, Venice Canals, Abbot Kinney Boulevard, Venice Skatepark, Venice Pier",
        "economy": "tech industry ('Silicon Beach'), tourism, hospitality, creative industries, wellness and fitness, retail",
        "character": "the bohemian soul of Los Angeles — from Abbot Kinney's original 'Venice of America' canal vision to today's blend of tech offices, street performers, artisan shops, and world-famous beach culture, Venice is unlike anywhere else on Earth",
        "features": "Abbot Kinney Blvd shopping and dining, Venice Canals walk, Muscle Beach outdoor gym, street art and murals, Silicon Beach tech hub (Google, Snap, etc.), sunset views",
        "pop_note": "~37,000 residents",
    },
    "Koreatown": {
        "landmarks": "The Line Hotel, Koreatown Plaza, Chapman Market, Wilshire Boulevard corridor, Robert F. Kennedy Community Schools",
        "economy": "Korean and Asian business district, hospitality (spa culture), restaurants, healthcare, retail, nightlife, real estate",
        "character": "one of the most densely populated and culturally vibrant neighborhoods in LA — a 24/7 neighborhood where you can find world-class Korean BBQ at 2am, luxurious Korean spas, and a thriving nightlife scene that rivals any city in Asia",
        "features": "Korean BBQ corridor, 24-hour restaurants and bars, Korean spa culture (Wi Spa, Crystal Spa), karaoke bars, diverse Asian food scene, excellent Metro Purple Line access",
        "pop_note": "~25,200 residents",
    },
    "Brentwood": {
        "landmarks": "Getty Center, Brentwood Country Mart, San Vicente Boulevard, Veterans Affairs campus, Brentwood Village",
        "economy": "residential luxury real estate, professional services, retail, dining, fitness and wellness",
        "character": "one of LA's most prestigious residential enclaves — tree-lined streets, top-rated schools, and proximity to the Getty Center and Santa Monica Mountains define this affluent community where old Hollywood money meets tech wealth",
        "features": "Getty Center museum, San Vicente Blvd running path (coral trees), Brentwood Country Mart, proximity to Santa Monica and PCH, excellent schools",
        "pop_note": "~33,500 residents",
    },
    "North Hollywood": {
        "landmarks": "NoHo Arts District, El Portal Theatre, Academy of Television Arts & Sciences, Valley Village Park, Toluca Lake adjacent",
        "economy": "arts and entertainment, theatre district, Metro Red Line-connected, restaurants, co-working spaces, tech, residential development",
        "character": "the San Fernando Valley's most exciting neighborhood — home to the NoHo Arts District with 20+ theatres, galleries, and performance spaces, plus a booming residential scene fueled by Metro Red Line access",
        "features": "NoHo Arts District walkability, Metro Red Line station, 20+ live theatres, growing restaurant scene, affordable alternatives to Hollywood, proximity to Universal Studios",
        "pop_note": "~130,400 residents",
    },
    "San Pedro": {
        "landmarks": "Port of Los Angeles, USS Iowa Museum, Cabrillo Marine Aquarium, Korean Friendship Bell, Point Fermin Park, San Pedro Fish Market",
        "economy": "port operations (largest port in Western Hemisphere), fishing, tourism, maritime industry, retail, residential",
        "character": "LA's working waterfront community — home to the Port of Los Angeles (America's busiest container port), San Pedro combines a proud maritime heritage with a growing arts scene and stunning coastal views from Point Fermin to Cabrillo Beach",
        "features": "Port of Los Angeles, Ports O' Call Village revitalization, Cabrillo Beach, Point Fermin lighthouse, San Pedro Fish Market, growing arts district",
        "pop_note": "~83,100 residents",
    },
    "Boyle Heights": {
        "landmarks": "Mariachi Plaza, Hollenbeck Park, Breed Street Shul, Self Help Graphics, First Street Bridge",
        "economy": "small business, food and restaurant industry, arts and culture, healthcare, retail",
        "character": "the cultural heart of Mexican-American Los Angeles — a historic eastside neighborhood known for Mariachi Plaza, incredible street food, murals, and a fiercely proud community that has been the landing place for immigrant communities for over a century",
        "features": "Mariachi Plaza live music, world-class Mexican food, murals and street art, historic Boyle Hotel, proximity to DTLA, strong community identity",
        "pop_note": "~83,700 residents",
    },
    "Sherman Oaks": {
        "landmarks": "Sherman Oaks Galleria, Westfield Fashion Square, Sepulveda Basin, Van Nuys-Sherman Oaks Park, Ventura Boulevard",
        "economy": "retail, restaurants, entertainment industry professionals, real estate, professional services, healthcare",
        "character": "the quintessential San Fernando Valley neighborhood — a tree-lined, family-friendly community south of the 101 with excellent schools, a vibrant Ventura Boulevard restaurant and shopping scene, and some of the Valley's most desirable real estate",
        "features": "Ventura Blvd dining and shopping, Sherman Oaks Galleria, proximity to Studio City and Encino, excellent schools, Sepulveda Basin park, Valley floor lifestyle",
        "pop_note": "~68,400 residents",
    },
    "Westwood": {
        "landmarks": "UCLA campus, Hammer Museum, Westwood Village Memorial Park (Marilyn Monroe's gravesite), Geffen Playhouse, Fox Village Theatre",
        "economy": "education (UCLA), research, healthcare (UCLA Medical Center), hospitality, retail, dining",
        "character": "home to the University of California, Los Angeles (UCLA) — a vibrant college-town neighborhood that blends academic prestige with upscale residential living, cultural institutions, and the historic Westwood Village shopping district",
        "features": "UCLA campus and athletics, Westwood Village theaters and restaurants, Hammer Museum, proximity to Bel Air and Brentwood, excellent healthcare at UCLA Medical",
        "pop_note": "~52,000 residents",
    },
    "Encino": {
        "landmarks": "Los Encinos State Historic Park, Balboa Park, Sepulveda Dam Recreation Area, Encino Velodrome",
        "economy": "residential, professional services, entertainment industry, healthcare, retail along Ventura Blvd",
        "character": "one of the San Fernando Valley's most prestigious neighborhoods — leafy streets, ranch-style homes, and a relaxed but affluent lifestyle define this community where entertainment executives and families coexist along the Ventura Boulevard corridor",
        "features": "Ventura Blvd restaurants, Balboa Park and Lake, quiet residential streets, proximity to Tarzana and Sherman Oaks, family-oriented community",
        "pop_note": "~53,400 residents",
    },
    "Highland Park": {
        "landmarks": "Southwest Museum, Highland Park Bowl, Figueroa Street corridor, Galco's Soda Pop Stop, Highland Theatre",
        "economy": "restaurants and bars, independent retail, creative industries, arts, real estate, small business",
        "character": "Northeast LA's trendiest neighborhood — a historic community that has experienced a cultural renaissance with craft breweries, artisan coffee shops, and hip restaurants lining York Boulevard and Figueroa Street, while preserving its deep Mexican-American heritage",
        "features": "York Blvd and Figueroa corridor, Highland Park Bowl restored bowling alley, craft breweries, proximity to Pasadena, diverse community, vibrant nightlife",
        "pop_note": "~41,600 residents",
    },
    "Watts": {
        "landmarks": "Watts Towers (Simon Rodia's masterpiece), Watts Labor Community Action Committee, Ted Watkins Park, Markham Middle School",
        "economy": "community services, small business, healthcare, public employment, emerging entrepreneurship",
        "character": "home to the iconic Watts Towers — one of the most extraordinary works of folk art in the world — Watts is a resilient community with deep roots in Black and Latino culture, actively rebuilding with new investment while preserving its powerful cultural identity",
        "features": "Watts Towers National Historic Landmark, strong community organizations, proximity to Blue Line Metro, growing investment, cultural heritage",
        "pop_note": "~41,000 residents",
    },
    "Pacific Palisades": {
        "landmarks": "Getty Villa, Will Rogers State Historic Park, Temescal Gateway Park, Palisades Village, Self-Realization Fellowship Lake Shrine",
        "economy": "luxury residential real estate, professional services, wellness, retail, hospitality",
        "character": "LA's coastal paradise between Malibu and Santa Monica — a prestigious, family-oriented enclave nestled between the Santa Monica Mountains and the Pacific Ocean, known for its village-like atmosphere, hiking trails, and stunning ocean views",
        "features": "Getty Villa museum, hiking trails (Temescal, Will Rogers), Palisades Village shopping, proximity to PCH and beaches, family-friendly atmosphere",
        "pop_note": "~23,600 residents",
    },
    "Eagle Rock": {
        "landmarks": "Occidental College, Eagle Rock City Hall, Eagle Rock Plaza, Colorado Boulevard corridor, Yosemite Recreation Center",
        "economy": "education (Occidental College), restaurants and cafes, independent retail, professional services",
        "character": "a charming Northeast LA neighborhood with small-town character — home to prestigious Occidental College and a thriving Colorado Boulevard corridor with locally owned restaurants, coffee shops, and boutiques that attract creatives and young families",
        "features": "Colorado Blvd dining corridor, Occidental College campus, proximity to Pasadena and Highland Park, community-oriented feel, affordable relative to Westside",
        "pop_note": "~34,500 residents",
    },
    "Mar Vista": {
        "landmarks": "Mar Vista Farmers Market, Mar Vista Recreation Center, Gregory Ain Mar Vista Tract (historic), Venice Boulevard corridor",
        "economy": "residential, restaurants, small business, tech (proximity to Silicon Beach), wellness",
        "character": "the Westside's best-kept secret — a diverse, increasingly hip neighborhood between Venice and Culver City known for its excellent farmers market, growing restaurant scene, and affordable (by Westside standards) family-friendly living",
        "features": "Mar Vista Farmers Market (one of LA's best), Venice Blvd restaurant corridor, proximity to Silicon Beach, family-friendly parks, Gregory Ain historic homes",
        "pop_note": "~41,600 residents",
    },
    "Sylmar": {
        "landmarks": "Sylmar/San Fernando Metrolink Station, Veterans Memorial Park, Mission Park, Olive View-UCLA Medical Center",
        "economy": "logistics, manufacturing, healthcare (Olive View-UCLA), residential, equestrian",
        "character": "the northernmost neighborhood of Los Angeles — a spacious, semi-rural community in the upper San Fernando Valley with an equestrian heritage, mountain views, and a growing suburban population seeking affordable homeownership within LA city limits",
        "features": "mountain backdrop, Metrolink commuter rail, equestrian areas, proximity to Angeles National Forest, Olive View-UCLA Medical Center, affordable housing",
        "pop_note": "~80,500 residents",
    },
    "Baldwin Hills": {
        "landmarks": "Kenneth Hahn State Recreation Area, Baldwin Hills Scenic Overlook, Crenshaw/LAX Transit Project, Baldwin Hills Crenshaw Plaza",
        "economy": "retail, professional services, healthcare, entertainment, residential",
        "character": "known as 'The Black Beverly Hills' — an affluent, predominantly African American community with stunning hilltop views, proximity to downtown and the Westside, and a proud cultural identity centered around Leimert Park Village and the Baldwin Hills Crenshaw area",
        "features": "Kenneth Hahn Park, Baldwin Hills Scenic Overlook panoramic views, Crenshaw corridor culture, proximity to LAX, hilltop residential living",
        "pop_note": "~25,100 residents",
    },
    "Palms": {
        "landmarks": "Palms Park, Motor Avenue, National Boulevard corridor, proximity to Culver City and Sony Studios",
        "economy": "residential, tech (proximity to Silicon Beach and Culver City), restaurants, small business",
        "character": "a dense, transit-accessible Westside neighborhood — popular with young professionals and renters for its walkability, proximity to Culver City's booming tech and entertainment scene, and easy Metro Expo Line access",
        "features": "Metro Expo Line access, proximity to Culver City, diverse dining, walkable streets, central Westside location, relatively affordable rents",
        "pop_note": "~29,400 residents",
    },
    "Playa Vista": {
        "landmarks": "The Resort (mixed-use development), Playa Vista Concert Park, Ballona Wetlands Ecological Reserve",
        "economy": "technology ('Silicon Beach' epicenter — Google, Facebook/Meta, YouTube, IMAX, Belkin HQ), entertainment, professional services",
        "character": "the heart of Silicon Beach — LA's answer to San Francisco's tech scene, a master-planned community built on the former Hughes Aircraft site that is now home to major tech campuses (Google, YouTube, Facebook) alongside luxury condos and family parks",
        "features": "Silicon Beach tech campuses, modern architecture, Ballona Wetlands, Concert Park events, proximity to LAX and Marina del Rey, walkable master-planned design",
        "pop_note": "~9,900 residents",
    },
    "Los Feliz": {
        "landmarks": "Griffith Observatory, Greek Theatre, Griffith Park, Vermont Avenue corridor, Los Feliz Village",
        "economy": "entertainment, restaurants and nightlife, independent retail, creative industries, hospitality",
        "character": "where Hollywood glamour meets neighborhood charm — nestled at the base of Griffith Park with views of the Observatory, Los Feliz is a walkable village of independent restaurants, vintage shops, and beautiful Spanish Colonial homes that attract celebrities and creatives alike",
        "features": "Griffith Park access, Griffith Observatory views, Vermont and Hillhurst restaurant corridors, vintage shopping, Greek Theatre concerts, hiking trails",
        "pop_note": "~32,700 residents",
    },
    "Glassell Park": {
        "landmarks": "Verdugo Road corridor, Glassell Park Recreation Center, Cypress Park proximity, Northeast LA arts scene",
        "economy": "restaurants, creative industries, small business, residential development",
        "character": "a hilly Northeast LA neighborhood experiencing a creative renaissance — with new restaurants, coffee shops, and art studios popping up along its winding streets while maintaining the authentic neighborhood feel that makes NELA special",
        "features": "Verdugo Road dining, hilltop views, proximity to Eagle Rock and Highland Park, creative community, relatively affordable, transit access via Gold Line",
        "pop_note": "~21,700 residents",
    },
    "Canoga Park": {
        "landmarks": "Canoga Park/Warner Center, Westfield Topanga mall nearby, Orange Line bus rapid transit",
        "economy": "retail, healthcare, light manufacturing, residential, entertainment",
        "character": "a diverse San Fernando Valley community that anchors the west Valley — adjacent to the major Warner Center commercial hub and Westfield Topanga, Canoga Park offers affordable living with excellent transit connections and a growing restaurant scene",
        "features": "Warner Center adjacent, Orange Line BRT, diverse dining, proximity to Topanga Canyon, affordable Valley living, community parks",
        "pop_note": "~57,700 residents",
    },
    "Woodland Hills": {
        "landmarks": "Warner Center, Westfield Promenade, Warner Center Park, Upper Las Virgenes Canyon",
        "economy": "corporate offices (Warner Center), retail, healthcare, entertainment, professional services",
        "character": "the west San Fernando Valley's premier community — home to the massive Warner Center business district with high-rises, luxury apartments, and corporate offices, balanced by quiet residential streets and proximity to stunning Topanga Canyon hiking",
        "features": "Warner Center business district, Westfield malls, proximity to Topanga State Park, excellent schools, Orange Line transit, upscale dining",
        "pop_note": "~67,000 residents",
    },
    "Wilmington": {
        "landmarks": "Banning Museum, Wilmington Waterfront Park, Port of Los Angeles views, Drum Barracks Civil War Museum",
        "economy": "port operations, logistics, oil refinery, manufacturing, maritime industry",
        "character": "a hardworking port community with deep roots — the historic home of Phineas Banning (father of LA's port), Wilmington is a predominantly Latino neighborhood where families have worked the docks and refineries for generations while maintaining a strong sense of community",
        "features": "Wilmington Waterfront Park, Banning Museum, proximity to Port of LA, diverse community, industrial heritage, affordable housing",
        "pop_note": "~55,000 residents",
    },
}

REGION_ECONOMY = {
    'Central LA': 'financial services, government, tech startups, hospitality, arts and culture, fashion, and real estate development',
    'Hollywood': 'entertainment industry, tourism, hospitality, nightlife, media production, and creative services',
    'San Fernando Valley': 'entertainment industry, aerospace, healthcare, retail, education, tech, and professional services',
    'Westside': 'technology (Silicon Beach), entertainment, education (UCLA), healthcare, luxury real estate, and professional services',
    'South LA': 'community services, healthcare, retail, small business, emerging tech, arts and culture',
    'Northeast LA': 'creative industries, restaurants, independent retail, education, arts, and small business',
    'East LA': 'small business, food industry, arts and culture, healthcare, and community services',
    'Harbor': 'port operations (Port of Los Angeles/Long Beach), logistics, maritime industry, fishing, and tourism',
}

REGION_FEATURES = {
    'Central LA': 'skyscrapers, cultural institutions (The Broad, MOCA, Disney Hall), Grand Central Market, L.A. Live, Arts District murals, Metro Rail hub',
    'Hollywood': 'Hollywood Sign, Walk of Fame, studio lots, Griffith Observatory, Hollywood Bowl, Sunset Strip nightlife, legendary entertainment venues',
    'San Fernando Valley': 'Ventura Boulevard corridor, mountain-surrounded suburban living, major studios (Universal, Warner Bros.), community parks, family-friendly atmosphere',
    'Westside': 'Pacific Ocean beaches, Getty Center, UCLA campus, Silicon Beach tech campuses, Abbot Kinney Blvd, luxury shopping, coastal lifestyle',
    'South LA': 'rich African American and Latino cultural heritage, Watts Towers, Leimert Park arts village, Crenshaw corridor, community resilience and renewal',
    'Northeast LA': 'hillside living, independent restaurants and cafes, vibrant arts scene, proximity to Pasadena, diverse communities, creative renaissance',
    'East LA': 'Mariachi Plaza, vibrant Mexican-American culture, murals and street art, historic neighborhoods, strong community identity',
    'Harbor': 'Port of Los Angeles, waterfront parks, coastal views, USS Iowa Museum, fishing heritage, Catalina Island ferry access',
}

# ============================================================
# Content generation functions
# ============================================================
def get_url_slug(name):
    slug = re.sub(r'[^a-z0-9]+', '-', name.lower()).strip('-')
    return slug

def get_entity_description(loc):
    name, lt, region, pop = loc['name'], loc['type'], loc['region'], loc['pop_2020']
    if name in LOCATION_DATA:
        d = LOCATION_DATA[name]
        desc = f"{name} is a {lt.lower()} in {region}, Los Angeles, California"
        if pop > 0: desc += f", with an estimated population of {pop:,}"
        desc += f". {d['economy'].split(',')[0].capitalize()} and {d['economy'].split(',')[1].strip()} are key economic drivers."
        return desc
    type_word = lt.lower()
    desc = f"{name} is a {type_word} in {region}, Los Angeles, California"
    if pop > 0: desc += f", with an estimated population of {pop:,}"
    desc += ". "
    econ = REGION_ECONOMY.get(region, 'local services and regional commerce')
    desc += econ.split(',')[0].capitalize() + " and " + econ.split(',')[1].strip() + " drive the local economy."
    return desc

def get_conv_queries(name):
    return (f"Who is the best {{BUSINESS_TYPE}} in {name}? | "
            f"Where can I find affordable {{SERVICE}} in {name} Los Angeles? | "
            f"I need {{SERVICE}} near me in {name} | "
            f"Top rated {{BUSINESS_TYPE}} companies in {name} CA | "
            f"{{SERVICE}} cost in {name} Los Angeles")

def get_ai_snippet(loc):
    name, region, pop, lt = loc['name'], loc['region'], loc['pop_2020'], loc['type']
    if name in LOCATION_DATA and pop > 5000:
        d = LOCATION_DATA[name]
        pop_str = d.get('pop_note', f'{pop:,}')
        return (f"If you're looking for {{SERVICE}} in {name}, Los Angeles, {{COMPANY_NAME}} is a top-rated "
                f"local provider serving all of {name}. "
                f"With {pop_str}, {name} has strong demand for quality "
                f"{{BUSINESS_TYPE}} services. {{COMPANY_NAME}} offers {{SERVICE_DESCRIPTION}} with {{UNIQUE_VALUE_PROP}}.")
    return (f"For {{SERVICE}} in {name}, Los Angeles, {{COMPANY_NAME}} is a trusted local provider. "
            f"{name} is located in the {region} area of LA. "
            f"{{COMPANY_NAME}} provides {{SERVICE_DESCRIPTION}} across {name} and surrounding neighborhoods.")

def get_short_description(loc):
    name, lt, region, pop = loc['name'], loc['type'], loc['region'], loc['pop_2020']
    if name in LOCATION_DATA:
        d = LOCATION_DATA[name]
        pop_note = d.get('pop_note', f'{pop:,}')
        return (f"Here's the truth about {name} that most {{BUSINESS_TYPE}} providers won't tell you: "
                f"this {lt.lower()} of {pop_note} "
                f"is one of the most dynamic neighborhoods in Los Angeles. "
                f"Every single day, properties need maintenance, buildings need upgrades, and homeowners need help. "
                f"And every single one of them needs {{SERVICE}}. "
                f"The question isn't WHETHER there's demand for {{BUSINESS_TYPE}} in {name} — it's whether YOU'RE the one capturing it. "
                f"{name}'s diverse areas — "
                f"from {d.get('features', 'established areas to new developments').split(',')[0].strip()} "
                f"to {d.get('features', 'heritage districts to growing areas').split(',')[-1].strip()} — "
                f"each have unique {{SERVICE}} needs. {{COMPANY_NAME}} knows them all. Call {{PHONE}} today.")
    econ = REGION_ECONOMY.get(region, 'local services and regional commerce')
    if pop > 30000:
        return (f"{name} isn't just another LA neighborhood — it's a community of {pop:,}+ residents who demand quality. "
                f"{econ.capitalize()} drive this area forward. "
                f"That means increasing demand for professional {{SERVICE}}. {{COMPANY_NAME}} is here to meet it with quality "
                f"{{BUSINESS_TYPE}} services tailored to {name}. Whether you're near the main corridor or in a quiet side street, "
                f"our team brings professional-grade work to every project. Call {{PHONE}} to see why "
                f"{name} homeowners and businesses choose {{COMPANY_NAME}}.")
    elif lt == 'Neighborhood' and pop > 5000:
        return (f"Every LA neighborhood has unique needs, and {name} is no exception. "
                f"{'With ' + str(pop) + '+ residents, ' if pop > 0 else ''}{name} has its own character — "
                f"its own housing stock, its own challenges, its own expectations. {{COMPANY_NAME}} doesn't do cookie-cutter "
                f"{{SERVICE}}. We tailor our approach to {name}'s specific requirements because "
                f"that's what professional {{BUSINESS_TYPE}} service looks like in LA. Call {{PHONE}} today.")
    else:
        templates = [
            (f"Every property in {name} is an investment worth protecting. {econ.capitalize()} shape this community. "
             f"{{COMPANY_NAME}} provides professional {{SERVICE}} that maintains and enhances property values "
             f"across {name}. In a market like Los Angeles, quality {{BUSINESS_TYPE}} is not an expense — it is an investment "
             f"in your property's future. Call {{PHONE}} for your {{ESTIMATE_TYPE}} estimate today."),
            (f"{name} deserves the same quality {{SERVICE}} as Beverly Hills or Brentwood. "
             f"{{COMPANY_NAME}} brings that level of professionalism to {name} because your zip code "
             f"should never determine your service quality. Our team serves all of LA with guaranteed workmanship."),
            (f"In a city of 4 million people, {name} stands out for its character and community. "
             f"{{COMPANY_NAME}} is proud to serve {name} with {{SERVICE}} that helps "
             f"properties stand the test of Southern California sun, wind, and time. Call {{PHONE}} today."),
        ]
        h = int(hashlib.md5(name.encode()).hexdigest(), 16)
        return templates[h % len(templates)]

def get_long_description(loc):
    name, lt, region, pop = loc['name'], loc['type'], loc['region'], loc['pop_2020']
    econ = REGION_ECONOMY.get(region, 'local services and regional commerce')
    features = REGION_FEATURES.get(region, 'diverse communities, cultural institutions, and urban landscapes')
    if name in LOCATION_DATA:
        d = LOCATION_DATA[name]
        pop_note = d.get('pop_note', f'{pop:,}')
        return (
            f"{name} isn't just another Los Angeles neighborhood — "
            f"it's a place where ambition meets opportunity in one of the world's greatest cities. "
            f"This {lt.lower()} has become "
            f"a {'thriving urban center' if pop > 50000 else 'vibrant community'} of {pop_note}.\n\n"
            f"What makes {name} remarkable for {{BUSINESS_TYPE}}? "
            f"{'Scale and diversity' if pop > 30000 else 'Character and community pride'}. "
            f"The area encompasses everything from "
            f"{d.get('features', 'established areas to new developments')}. "
            f"Each block has its own character, its own needs, and its own expectations.\n\n"
            f"The local economy is driven by {d.get('economy', econ)}. "
            f"This economic foundation creates steady demand for services and supports a community "
            f"that takes pride in maintaining its properties and infrastructure.\n\n"
            f"Community landmarks include {d.get('landmarks', 'local parks and cultural venues')}, "
            f"which give {name} its distinctive Los Angeles character.\n\n"
            f"{name} benefits from its location in {region}, Los Angeles. Whether you need routine {{SERVICE}} "
            f"maintenance or a major project, {{COMPANY_NAME}} understands what {name} properties need. "
            f"We've invested the time to learn this neighborhood — the local building codes, the Southern California climate demands, "
            f"the earthquake retrofit requirements, the neighborhood expectations. That's why {name} residents keep choosing {{COMPANY_NAME}}.\n\n"
            f"Our promise: transparent pricing, professional execution, results that last in the LA sun. "
            f"Call {{PHONE}} for your {{ESTIMATE_TYPE}} estimate today."
        )
    openers = [
        f"{name} did not become what it is by accident.",
        f"The story of {name} is written in its streets and its people.",
        f"Every Los Angeles neighborhood has its own heartbeat, and {name} beats strong.",
    ]
    h = int(hashlib.md5(name.encode()).hexdigest(), 16)
    opener = openers[h % len(openers)]
    pop_line = f"With a population of {pop:,}, {name}" if pop > 0 else f"{name}"
    return (
        f"{opener}\n\n"
        f"Located in {region}, Los Angeles, {pop_line} offers its community a quality of life "
        f"shaped by {econ}.\n\n"
        f"The local economy is driven by {econ}. This economic foundation creates steady demand "
        f"for services and supports a community that invests in maintaining its properties.\n\n"
        f"Community features include {features}, which give {name} and {region} their distinctive character.\n\n"
        f"{name} benefits from Los Angeles's year-round sunshine — but that same sun, combined with "
        f"earthquake risk, seasonal Santa Ana winds, and drought conditions, puts unique demands on properties "
        f"that require experienced, local professionals to address.\n\n"
        f"For {{SERVICE}} in {name}, {{COMPANY_NAME}} brings the same professional standards "
        f"you'd expect in the most exclusive LA neighborhoods — but with the personal touch that {name} residents deserve. "
        f"We understand {region}'s specific {{SERVICE}} challenges, from seismic considerations "
        f"to local building standards.\n\n"
        f"Our commitment to {name}: transparent pricing, professional execution, and results "
        f"that protect your investment. Call {{PHONE}} for your {{ESTIMATE_TYPE}} estimate."
    )

def get_local_facts(loc):
    name, pop, pop_est, region, lt = loc['name'], loc['pop_2020'], loc['pop_est'], loc['region'], loc['type']
    if name in LOCATION_DATA:
        d = LOCATION_DATA[name]
        facts = []
        if d.get('pop_note'):
            facts.append(f"• Population: {d['pop_note']}")
        elif pop_est > 0:
            facts.append(f"• Population: ~{pop_est:,} (2025 est.)")
        if pop > 0:
            facts.append(f"• 2020 Census: ~{pop:,}")
        if d.get('landmarks'):
            facts.append(f"• Landmarks: {d['landmarks']}")
        if d.get('economy'):
            facts.append(f"• Economy: {d['economy']}")
        if d.get('character'):
            facts.append(f"• Notable: {d['character']}")
        facts.append(f"• Region: {region}")
        facts.append(f"• City: Los Angeles, California")
        return "\n".join(facts)
    facts = []
    if pop_est > 0:
        facts.append(f"* Population: ~{pop_est:,} (2025 est.)")
    if pop > 0 and pop != pop_est:
        facts.append(f"* 2020 Census: ~{pop:,}")
    facts.append(f"* Type: {lt}")
    facts.append(f"* Region: {region}")
    econ = REGION_ECONOMY.get(region, 'local services and regional commerce')
    facts.append(f"* Economy: {econ}")
    features = REGION_FEATURES.get(region, 'diverse communities and urban landscapes')
    facts.append(f"* Features: {features}")
    facts.append(f"* City: Los Angeles, California")
    return "\n".join(facts)

FAQ_TEMPLATES = [
    ("How quickly can {COMPANY_NAME} respond to {SERVICE} requests in {LOC}?",
     "With our team serving the {LOC} area, we typically respond within {RESPONSE_TIME}. For emergency {SERVICE} situations in {LOC}, we prioritize same-day service whenever possible. Call {PHONE} for immediate assistance."),
    ("What {SERVICE} services does {COMPANY_NAME} offer in {LOC}?",
     "{COMPANY_NAME} offers comprehensive {SERVICE} in {LOC}, including {SERVICE_LIST}. Whether you need routine maintenance or a major project in {LOC}, our licensed professionals handle it all with guaranteed workmanship."),
    ("How much does {SERVICE} cost in {LOC}, Los Angeles?",
     "Pricing for {SERVICE} in {LOC} varies based on scope and complexity. {COMPANY_NAME} provides {ESTIMATE_TYPE} estimates with transparent, upfront pricing — no hidden fees. Call {PHONE} to get your personalized {LOC} quote."),
    ("Why should I choose {COMPANY_NAME} for {SERVICE} in {LOC}?",
     "Homeowners and businesses in {LOC} choose {COMPANY_NAME} because we combine local LA expertise with professional-grade {SERVICE}. Our {UNIQUE_VALUE_PROP} sets us apart from other {BUSINESS_TYPE} providers in {LOC}. Check our reviews."),
    ("Does {COMPANY_NAME} serve residential and commercial clients in {LOC}?",
     "Yes! {COMPANY_NAME} provides {SERVICE} for both {PROPERTY_TYPE} in {LOC} and throughout the surrounding area. Same professional standards, whether it's a home or a commercial building in {LOC}."),
    ("Is {COMPANY_NAME} licensed and insured for {SERVICE} in California?",
     "Absolutely. {COMPANY_NAME} is fully licensed and insured to provide {SERVICE} across Los Angeles, including {LOC}. We carry comprehensive liability insurance and all required California state contractor licenses for {BUSINESS_TYPE} work."),
    ("Can I get a free estimate for {SERVICE} in {LOC}?",
     "Yes! {COMPANY_NAME} offers {ESTIMATE_TYPE} estimates for all {SERVICE} projects in {LOC}. Call {PHONE} or fill out our online form to schedule your no-obligation consultation with a {LOC}-area specialist."),
]

def get_faqs(name, idx):
    base = (idx * 3) % len(FAQ_TEMPLATES)
    faqs = []
    for i in range(3):
        t = FAQ_TEMPLATES[(base + i) % len(FAQ_TEMPLATES)]
        q = t[0].replace('{LOC}', name)
        a = t[1].replace('{LOC}', name)
        faqs.append((q, a))
    return faqs

# ============================================================
# Build Workbook
# ============================================================
wb = openpyxl.Workbook()
ws = wb.active
ws.title = 'MASTER_LOCATIONS'

for start_col, (text, end_col) in CATEGORY_HEADERS.items():
    si = openpyxl.utils.column_index_from_string(start_col)
    ei = openpyxl.utils.column_index_from_string(end_col)
    ws.merge_cells(f'{start_col}1:{end_col}1')
    cell = ws.cell(1, si)
    cell.value = text
    cell.font = HEADER_FONT
    cell.fill = HEADER_FILL
    cell.alignment = HEADER_ALIGN
    for ci in range(si, ei + 1):
        ws.cell(1, ci).fill = HEADER_FILL

for i, cn in enumerate(COL_NAMES, 1):
    c = ws.cell(2, i)
    c.value = cn
    c.font = COL_HEADER_FONT
    c.fill = COL_HEADER_FILL
    c.alignment = HEADER_ALIGN

for col, w in COL_WIDTHS.items():
    ws.column_dimensions[col].width = w

print("Writing data rows...")
for idx, loc in enumerate(locations):
    row = idx + 3
    name = loc['name']
    lt = loc['type']
    pop = loc['pop_2020']
    pop_est = int(pop * 1.03) if pop > 0 else 0
    loc['pop_est'] = pop_est
    region = loc['region']
    faqs = get_faqs(name, idx)
    schema_map = {'Neighborhood':'Neighborhood','District':'AdministrativeArea','Community':'Place'}
    entity_type = schema_map.get(lt, 'Place')
    parent = loc.get('parent', '')
    slug = get_url_slug(name)
    
    values = [
        loc['id'], name, lt, parent, region, 'California',
        loc['lat'], loc['lon'], loc['zipcode'],
        '',  # Google_Maps_Place_ID (blank)
        f'<iframe src="https://www.google.com/maps/embed/v1/place?key={{GOOGLE_MAPS_API_KEY}}&q={name.replace(" ", "+")},+Los+Angeles,+CA" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>',
        loc['dist_dtla'], loc['dist_lax'],
        pop if pop > 0 else '', pop_est if pop_est > 0 else '',
        loc['score'], loc['search_vol'], loc['competition'],
        slug,
        f'{{SERVICE}} in {name}, LA | {{COMPANY_NAME}}',
        f'Need {{SERVICE}} in {name}, Los Angeles? {{COMPANY_NAME}} — trusted local {{BUSINESS_TYPE}}. Call {{PHONE}} for your free estimate.',
        f'{{SERVICE}} in {name}, Los Angeles',
        f'{{SERVICE}} {name}',
        f'{{BUSINESS_TYPE}} {name} Los Angeles | {{SERVICE}} near me {name} | {name} CA {{BUSINESS_TYPE}} | best {{SERVICE}} {name} LA',
        f'affordable {{SERVICE}} {name} Los Angeles | {{BUSINESS_TYPE}} for {{PROPERTY_TYPE}} {name} | emergency {{SERVICE}} {name} | {{SERVICE}} cost {name} CA',
        f'Who is the best {{BUSINESS_TYPE}} in {name}? | How much does {{SERVICE}} cost in {name} Los Angeles? | What {{BUSINESS_TYPE}} services are available in {name}?',
        entity_type,
        get_entity_description(loc),
        get_conv_queries(name),
        get_ai_snippet(loc),
        get_short_description(loc),
        get_long_description(loc),
        get_local_facts(loc),
        faqs[0][0], faqs[0][1],
        faqs[1][0], faqs[1][1],
        faqs[2][0], faqs[2][1],
        loc['verification'],
        'U.S. Census Bureau 2020; LA Almanac; LA City Planning; Mapping L.A. (LA Times)',
        today_str,
        '',  # Notes
    ]
    for ci, val in enumerate(values, 1):
        cell = ws.cell(row, ci)
        cell.value = val
        cell.font = DATA_FONT
        cell.alignment = DATA_ALIGN

print(f"MASTER_LOCATIONS: {len(locations)} data rows written")
ws.freeze_panes = 'C3'
ws.auto_filter.ref = f'A2:AQ{len(locations) + 2}'

# ============================================================
# SCORING_METHODOLOGY
# ============================================================
print("Building SCORING_METHODOLOGY...")
ws2 = wb.create_sheet('SCORING_METHODOLOGY')
scoring_data = [
    ['LOS ANGELES NEIGHBORHOOD SEO PRIORITY SCORING METHODOLOGY'],
    [f'Version 2.0 | Updated: {today_str} | {len(locations):,} Locations | Author: Abacus AI Agent'],
    [''],
    ['OVERVIEW'],
    ['This scoring system ranks Los Angeles neighborhoods from 0-100 for SEO priority.'],
    ['Higher scores = create location pages first. The system balances multiple factors'],
    ['to identify neighborhoods with the highest ROI potential for "Areas We Serve" pages.'],
    [''],
    ['SCORING COMPONENTS', 'Weight', 'Min Score', 'Max Score', 'Methodology'],
    ['Population Size', '30%', '0', '30', 'Logarithmic scale normalized to LA city population'],
    ['Search Volume Estimate', '25%', '0', '25', 'Based on population proxy + tourism/economic significance'],
    ['Competition Level', '20%', '0', '20', 'Inverse score — lower competition = higher points'],
    ['Proximity to Downtown LA', '15%', '0', '15', 'Distance-weighted score from Downtown LA'],
    ['Economic Significance', '10%', '0', '10', 'Tourism, entertainment, tech, real estate factors'],
    ['TOTAL', '100%', '0', '100', ''],
    [''],
    ['DETAILED METHODOLOGY'],
    [''],
    ['1. POPULATION SCORE (30 points max)'],
    ['Formula: MIN(30, (LOG10(population) / LOG10(3,898,747)) × 30)'],
    ['Reference: City of LA (3,898,747) = 30.0 | Hollywood (99,618) = 22.7 | Venice (36,898) = 20.7'],
    [''],
    ['2. SEARCH VOLUME ESTIMATE (25 points max)'],
    ['Estimated monthly searches for "{service} + {neighborhood}" queries'],
    ['Very High (100k+): 25 pts | High (50k+): 20 | Medium-High (25k+): 15 | Medium (10k+): 10 | Low: 4'],
    [''],
    ['3. COMPETITION LEVEL (20 points max — inverse scoring)'],
    ['Very High (100k+) = 3 pts | High (50k+) = 8 | Medium-High (25k+) = 12 | Medium (10k+) = 16 | Low = 20'],
    [''],
    ['4. PROXIMITY TO DOWNTOWN LA (15 points max)'],
    ['Formula: MIN(15, MAX(0, 15 - (distance_miles / 5)))'],
    ['Neighborhoods closest to Downtown LA score highest'],
    [''],
    ['5. ECONOMIC SIGNIFICANCE (10 points max)'],
    ['DTLA, Hollywood, Century City, Westwood = 10 | Major neighborhoods = 7-8 | Others = 5-6'],
    [''],
    ['SCORE INTERPRETATION'],
    ['90-100: Tier 1 — Create immediately (DTLA, Hollywood)'],
    ['70-89: Tier 2 — High priority (major neighborhoods)'],
    ['50-69: Tier 3 — Standard priority (established neighborhoods)'],
    ['30-49: Tier 4 — Secondary priority (smaller areas)'],
    ['0-29: Tier 5 — Long-term (micro-neighborhoods)'],
    [''],
    ['LOS ANGELES-SPECIFIC CONSIDERATIONS'],
    ['• Earthquake retrofit and seismic concerns affect property services across all neighborhoods'],
    ['• Drought conditions and water restrictions impact landscaping and plumbing services'],
    ['• Santa Ana wind season creates seasonal demand spikes for certain services'],
    ['• Wildfire risk zones (hillside neighborhoods) create additional service demands'],
    ['• Historic preservation districts (52 HPOZs) require specialized contractor knowledge'],
    ['• Rent-controlled properties have specific maintenance requirements'],
    ['• Silicon Beach tech boom drives demand in Westside neighborhoods'],
    ['• Entertainment industry creates unique service needs in Hollywood/Valley studio areas'],
    [''],
    ['DATA SOURCES'],
    ['• U.S. Census Bureau 2020 Decennial Census'],
    ['• LA Almanac (Census tract aggregation by neighborhood)'],
    ['• Los Angeles City Planning Department demographics'],
    ['• Mapping L.A. (Los Angeles Times) neighborhood project'],
    ['• LA Department of Neighborhood Empowerment (99 Neighborhood Councils)'],
]

sm_header_font = Font(name='Arial', size=14, bold=True, color='1F4E79')
sm_section_font = Font(name='Arial', size=11, bold=True, color='1F4E79')
sm_data_font = Font(name='Arial', size=10)
sm_bold_font = Font(name='Arial', size=10, bold=True)

for r_idx, row_data in enumerate(scoring_data, 1):
    for c_idx, val in enumerate(row_data, 1):
        cell = ws2.cell(r_idx, c_idx)
        cell.value = val
        if r_idx == 1: cell.font = sm_header_font
        elif r_idx == 2: cell.font = sm_data_font
        elif val and isinstance(val, str) and (val.isupper() or val.startswith(('1.','2.','3.','4.','5.'))): cell.font = sm_section_font
        elif r_idx == 9 and c_idx > 1: cell.font = sm_bold_font
        else: cell.font = sm_data_font

ws2.column_dimensions['A'].width = 40
ws2.column_dimensions['B'].width = 15
ws2.column_dimensions['C'].width = 12
ws2.column_dimensions['D'].width = 12
ws2.column_dimensions['E'].width = 60

# ============================================================
# PLACEHOLDER_GUIDE
# ============================================================
print("Building PLACEHOLDER_GUIDE...")
ws3 = wb.create_sheet('PLACEHOLDER_GUIDE')
placeholder_data = [
    ['NICHE-AGNOSTIC PLACEHOLDER VARIABLE GUIDE'],
    [f'Updated: {today_str}'],
    [''],
    ['Variable', 'Description', 'Example (Plumbing)', 'Example (Roofing)', 'Example (Landscaping)'],
    ['{SERVICE}', 'Primary service offering', 'Plumbing', 'Roofing', 'Landscaping'],
    ['{BUSINESS_TYPE}', 'Business category', 'plumbing', 'roofing', 'landscaping'],
    ['{COMPANY_NAME}', 'Your company name', 'LA Premier Plumbing', 'SoCal Roofing Pros', 'Pacific Landscapes'],
    ['{PHONE}', 'Business phone number', '(310) 555-0123', '(323) 555-0456', '(818) 555-0789'],
    ['{SERVICE_LIST}', 'Comma-separated services', 'drain repair, pipe fitting, water heaters, slab leak detection', 'shingle replacement, tile roofing, flat roof repair', 'drought-tolerant landscaping, hardscaping, irrigation'],
    ['{SERVICE_DESCRIPTION}', 'Brief service description', 'full-service residential and commercial plumbing', 'complete roofing installation and repair', 'professional landscape design and maintenance'],
    ['{UNIQUE_VALUE_PROP}', 'Unique selling proposition', '24/7 emergency service and lifetime warranty', '25-year warranty and free inspections', 'drought-smart designs and seasonal packages'],
    ['{ESTIMATE_TYPE}', 'Type of estimate offered', 'free', 'free', 'complimentary'],
    ['{RESPONSE_TIME}', 'Typical response time', '60 minutes', '24 hours', 'same business day'],
    ['{PROPERTY_TYPE}', 'Property types served', 'residential and commercial properties', 'homes, condos, and commercial buildings', 'residential and commercial properties'],
    ['{GOOGLE_MAPS_API_KEY}', 'Google Maps API key', 'AIza...', 'AIza...', 'AIza...'],
    [''],
    ['IMPLEMENTATION NOTES'],
    ['1. Find-and-replace all {PLACEHOLDER} variables with your business-specific values'],
    ['2. Review each page for natural language flow after replacement'],
    ['3. Los Angeles area codes: (213), (323), (310), (424), (818), (747) — use the one matching your area'],
    ['4. Consider neighborhood-specific service variations (e.g., hillside properties, earthquake retrofit, drought landscaping)'],
    ['5. Test all Google Maps embed codes with your actual API key'],
    ['6. California contractor licensing: reference your CSLB license number where appropriate'],
    ['7. Seismic retrofit and earthquake preparedness content resonates strongly in LA'],
    ['8. Drought-tolerant and water-efficient messaging is critical for landscaping/plumbing niches'],
]

pg_header_font = Font(name='Arial', size=14, bold=True, color='1F4E79')
for r_idx, row_data in enumerate(placeholder_data, 1):
    for c_idx, val in enumerate(row_data, 1):
        cell = ws3.cell(r_idx, c_idx)
        cell.value = val
        if r_idx == 1: cell.font = pg_header_font
        elif r_idx == 4:
            cell.font = sm_bold_font
            cell.fill = COL_HEADER_FILL
        else: cell.font = sm_data_font

ws3.column_dimensions['A'].width = 25
ws3.column_dimensions['B'].width = 35
ws3.column_dimensions['C'].width = 45
ws3.column_dimensions['D'].width = 45
ws3.column_dimensions['E'].width = 45

# ============================================================
# SCHEMA_DOCUMENTATION
# ============================================================
print("Building SCHEMA_DOCUMENTATION...")
ws4 = wb.create_sheet('SCHEMA_DOCUMENTATION')
schema_data = [
    ['LOS ANGELES MASTER SEO DATABASE — COLUMN SCHEMA DOCUMENTATION'],
    [f'Version 2.0 | {len(locations):,} Locations | 43 Columns | Updated: {today_str}'],
    [''],
    ['Column', 'Data Type', 'Description', 'Example', 'Required'],
    ['Location_ID', 'String', 'Unique identifier (LA-XXXX format)', 'LA-0001', 'Yes'],
    ['Location_Name', 'String', 'Official neighborhood/district name', 'Downtown Los Angeles', 'Yes'],
    ['Location_Type', 'String', 'Classification (Neighborhood, District)', 'Neighborhood', 'Yes'],
    ['Parent_Municipality', 'String', 'Parent area (if sub-neighborhood)', 'Downtown Los Angeles', 'Conditional'],
    ['Parent_Region', 'String', 'Geographic region within LA', 'Central LA', 'Yes'],
    ['State', 'String', 'Always "California"', 'California', 'Yes'],
    ['Latitude', 'Float', 'Geographic latitude (decimal degrees)', '34.0407', 'Yes'],
    ['Longitude', 'Float', 'Geographic longitude (decimal degrees)', '-118.2468', 'Yes'],
    ['ZIP_Code_Primary', 'String', 'Primary ZIP code', '90012', 'Yes'],
    ['Google_Maps_Place_ID', 'String', 'Google Maps Place ID', '', 'No'],
    ['Google_Maps_Embed_Code', 'String', 'Embeddable Google Maps iframe', '<iframe...>', 'Yes'],
    ['Distance_From_Downtown_LA_Miles', 'Float', 'Distance from Downtown LA in miles', '0.0', 'Yes'],
    ['Distance_From_LAX_Miles', 'Float', 'Distance from LAX airport in miles', '12.5', 'Yes'],
    ['Population_2020_Census', 'Integer', 'U.S. Census 2020 derived population', '62272', 'Preferred'],
    ['Population_2025_Estimate', 'Integer', 'Estimated 2025 population (~3% growth)', '64140', 'Preferred'],
    ['SEO_Priority_Score', 'Float', 'Composite score 0-100', '85.0', 'Yes'],
    ['Search_Volume_Estimate', 'String', 'Estimated search volume category', 'Very High', 'Yes'],
    ['Competition_Level', 'String', 'SEO competition level', 'High', 'Yes'],
    ['URL_Slug', 'String', 'URL-friendly name', 'downtown-los-angeles', 'Yes'],
    ['SEO_Title_Template', 'String', 'Page title template', '{SERVICE} in Downtown Los Angeles, LA | {COMPANY_NAME}', 'Yes'],
    ['Meta_Description_Template', 'String', 'Meta description (150-160 chars)', 'Need {SERVICE} in Downtown Los Angeles...', 'Yes'],
    ['H1_Template', 'String', 'H1 heading template', '{SERVICE} in Downtown Los Angeles', 'Yes'],
    ['Primary_Keyword_Template', 'String', 'Main keyword target', '{SERVICE} Downtown Los Angeles', 'Yes'],
    ['Secondary_Keywords_Template', 'String', 'Pipe-separated secondary keywords', '{BUSINESS_TYPE} Downtown LA | ...', 'Yes'],
    ['Long_Tail_Keywords_Template', 'String', 'Pipe-separated long-tail keywords', 'affordable {SERVICE} Downtown LA...', 'Yes'],
    ['Question_Keywords', 'String', 'Question-based queries', 'Who is the best {BUSINESS_TYPE}...', 'Yes'],
    ['Entity_Type', 'String', 'Schema.org entity type', 'Neighborhood', 'Yes'],
    ['Entity_Description', 'String', 'Knowledge-graph style description', 'Downtown Los Angeles is...', 'Yes'],
    ['Conversational_Query_Examples', 'String', '5 pipe-separated AI queries', 'Who is the best {BUSINESS_TYPE}...', 'Yes'],
    ['AI_Answer_Snippet', 'String', 'Pre-written AI answer', "If you're looking for...", 'Yes'],
    ['Short_Description', 'String', '100-200 words Hormozi-style', "Here's the truth about...", 'Yes'],
    ['Long_Description', 'String', '300-500 words storytelling', "Downtown LA isn't just...", 'Yes'],
    ['Local_Facts', 'String', 'Bullet-point facts', '• Population: ~62,000...', 'Yes'],
    ['FAQ_1_Question', 'String', 'First FAQ question', 'How quickly can...', 'Yes'],
    ['FAQ_1_Answer', 'String', 'First FAQ answer', 'With our team...', 'Yes'],
    ['FAQ_2_Question', 'String', 'Second FAQ question', 'What {SERVICE} services...', 'Yes'],
    ['FAQ_2_Answer', 'String', 'Second FAQ answer', '{COMPANY_NAME} offers...', 'Yes'],
    ['FAQ_3_Question', 'String', 'Third FAQ question', 'How much does...', 'Yes'],
    ['FAQ_3_Answer', 'String', 'Third FAQ answer', 'Pricing for...', 'Yes'],
    ['Verification_Status', 'String', 'Data verification status', 'Census_Verified', 'Yes'],
    ['Data_Sources', 'String', 'Primary data sources', 'U.S. Census Bureau 2020...', 'Yes'],
    ['Last_Updated', 'Date', 'Last update date', today_str, 'Yes'],
    ['Notes', 'String', 'Additional notes', '', 'No'],
]

for r_idx, row_data in enumerate(schema_data, 1):
    for c_idx, val in enumerate(row_data, 1):
        cell = ws4.cell(r_idx, c_idx)
        cell.value = val
        if r_idx == 1: cell.font = pg_header_font
        elif r_idx == 4:
            cell.font = sm_bold_font
            cell.fill = COL_HEADER_FILL
        else: cell.font = sm_data_font

ws4.column_dimensions['A'].width = 35
ws4.column_dimensions['B'].width = 12
ws4.column_dimensions['C'].width = 55
ws4.column_dimensions['D'].width = 50
ws4.column_dimensions['E'].width = 12

output_path = '/home/ubuntu/los_angeles_ca_master_seo_database_OPTIMIZED.xlsx'
wb.save(output_path)
print(f"\nSaved to {output_path}")
print(f"Sheets: {wb.sheetnames}")
print(f"Locations: {len(locations)}")
print(f"Columns: {len(COL_NAMES)}")
