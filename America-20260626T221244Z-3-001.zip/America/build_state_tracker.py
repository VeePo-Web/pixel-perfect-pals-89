#!/usr/bin/env python3
"""Build US States SEO Master Tracker for goldfindesk.com"""
import pandas as pd
import numpy as np
import math, re
from datetime import date
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.formatting.rule import CellIsRule

pd.set_option('display.max_columns', None)
pd.set_option('display.width', 200)

today_str = date.today().strftime('%Y-%m-%d')

# ============================================================
# Load all data sources
# ============================================================
# 1. Census sub-county estimates (for state populations and city counts)
census = pd.read_csv('census_sub_est.csv', encoding='latin-1')

# State populations
state_pop = census[census['SUMLEV'] == 40][['STNAME', 'ESTIMATESBASE2020']].copy()
state_pop.columns = ['State', 'Pop_2020']
# Remove DC from states list (we want 50 states only, but include DC data for reference)
# Actually, keep all — user said "50 US states" but DC is useful data

# City counts (100K+)
places = census[census['SUMLEV'] == 162][['NAME', 'STNAME', 'ESTIMATESBASE2020']].copy()
places.columns = ['City_Raw', 'State', 'Pop']
def clean_name(n):
    return re.sub(r'\s+(city|town|village|borough|CDP|municipality|unified government|metro government|city and borough|consolidated government)$', '', n, flags=re.IGNORECASE).strip()
places['City'] = places['City_Raw'].apply(clean_name)
places = places[~places['City_Raw'].str.contains('(balance)', case=False, na=False)]

# Cities >= 100K
major = places[places['Pop'] >= 100000].groupby('State').size().reset_index(name='Major_Cities')

# Top 3 cities per state
top3 = places.sort_values('Pop', ascending=False).groupby('State').head(3)
top3_str = top3.groupby('State').apply(
    lambda g: ', '.join(g['City'].values[:3]), include_groups=False
).reset_index(name='Top_3_Cities')

# 2. GDP data
gdp_df = pd.read_pickle('state_gdp.pkl')

# 3. Median household income (from web search results - 2023 ACS)
MHI = {
    'Alabama': 62212, 'Alaska': 88121, 'Arizona': 77315, 'Arkansas': 58700,
    'California': 95521, 'Colorado': 92911, 'Connecticut': 91665, 'Delaware': 82174,
    'Florida': 73311, 'Georgia': 74632, 'Hawaii': 95322, 'Idaho': 74942,
    'Illinois': 80306, 'Indiana': 69477, 'Iowa': 71433, 'Kansas': 70333,
    'Kentucky': 61118, 'Louisiana': 58229, 'Maine': 73733, 'Maryland': 98678,
    'Massachusetts': 99858, 'Michigan': 69183, 'Minnesota': 85086, 'Mississippi': 54203,
    'Missouri': 68545, 'Montana': 70804, 'Nebraska': 74590, 'Nevada': 76364,
    'New Hampshire': 96838, 'New Jersey': 99781, 'New Mexico': 62268, 'New York': 82095,
    'North Carolina': 70804, 'North Dakota': 76525, 'Ohio': 67769, 'Oklahoma': 62138,
    'Oregon': 80160, 'Pennsylvania': 73824, 'Rhode Island': 84972,
    'South Carolina': 67804, 'South Dakota': 71810, 'Tennessee': 67631,
    'Texas': 75780, 'Utah': 93421, 'Vermont': 81211, 'Virginia': 89931,
    'Washington': 94605, 'West Virginia': 55948, 'Wisconsin': 74631, 'Wyoming': 72415,
    'District of Columbia': 108210,
}

# State codes
STATE_CODES = {
    'Alabama':'AL','Alaska':'AK','Arizona':'AZ','Arkansas':'AR','California':'CA',
    'Colorado':'CO','Connecticut':'CT','Delaware':'DE','Florida':'FL','Georgia':'GA',
    'Hawaii':'HI','Idaho':'ID','Illinois':'IL','Indiana':'IN','Iowa':'IA',
    'Kansas':'KS','Kentucky':'KY','Louisiana':'LA','Maine':'ME','Maryland':'MD',
    'Massachusetts':'MA','Michigan':'MI','Minnesota':'MN','Mississippi':'MS','Missouri':'MO',
    'Montana':'MT','Nebraska':'NE','Nevada':'NV','New Hampshire':'NH','New Jersey':'NJ',
    'New Mexico':'NM','New York':'NY','North Carolina':'NC','North Dakota':'ND','Ohio':'OH',
    'Oklahoma':'OK','Oregon':'OR','Pennsylvania':'PA','Rhode Island':'RI','South Carolina':'SC',
    'South Dakota':'SD','Tennessee':'TN','Texas':'TX','Utah':'UT','Vermont':'VT',
    'Virginia':'VA','Washington':'WA','West Virginia':'WV','Wisconsin':'WI','Wyoming':'WY',
}

REGIONS = {
    'Connecticut': 'Northeast', 'Maine': 'Northeast', 'Massachusetts': 'Northeast',
    'New Hampshire': 'Northeast', 'Rhode Island': 'Northeast', 'Vermont': 'Northeast',
    'New Jersey': 'Northeast', 'New York': 'Northeast', 'Pennsylvania': 'Northeast',
    'Illinois': 'Midwest', 'Indiana': 'Midwest', 'Michigan': 'Midwest',
    'Ohio': 'Midwest', 'Wisconsin': 'Midwest', 'Iowa': 'Midwest',
    'Kansas': 'Midwest', 'Minnesota': 'Midwest', 'Missouri': 'Midwest',
    'Nebraska': 'Midwest', 'North Dakota': 'Midwest', 'South Dakota': 'Midwest',
    'Delaware': 'South', 'Florida': 'South', 'Georgia': 'South',
    'Maryland': 'South', 'North Carolina': 'South', 'South Carolina': 'South',
    'Virginia': 'South', 'West Virginia': 'South', 'Alabama': 'South',
    'Kentucky': 'South', 'Mississippi': 'South', 'Tennessee': 'South',
    'Arkansas': 'South', 'Louisiana': 'South', 'Oklahoma': 'South', 'Texas': 'South',
    'Arizona': 'West', 'Colorado': 'West', 'Idaho': 'West', 'Montana': 'West',
    'Nevada': 'West', 'New Mexico': 'West', 'Utah': 'West', 'Wyoming': 'West',
    'Alaska': 'West', 'California': 'West', 'Hawaii': 'West', 'Oregon': 'West',
    'Washington': 'West',
}

# ============================================================
# Build combined dataset
# ============================================================
fifty_states = [s for s in STATE_CODES.keys()]  # 50 states only (no DC)

rows = []
for state in fifty_states:
    pop_row = state_pop[state_pop['State'] == state]
    pop = int(pop_row['Pop_2020'].values[0]) if len(pop_row) > 0 else 0
    
    mc_row = major[major['State'] == state]
    major_cities = int(mc_row['Major_Cities'].values[0]) if len(mc_row) > 0 else 0
    
    gdp_row = gdp_df[gdp_df['State'] == state]
    gdp = float(gdp_row['GDP_2024'].values[0]) if len(gdp_row) > 0 else 0
    
    mhi = MHI.get(state, 65000)
    
    t3_row = top3_str[top3_str['State'] == state]
    top_cities = t3_row['Top_3_Cities'].values[0] if len(t3_row) > 0 else ''
    
    rows.append({
        'State': state,
        'State_Code': STATE_CODES[state],
        'Region': REGIONS.get(state, ''),
        'Pop_2020': pop,
        'Major_Cities': major_cities,
        'GDP_2024_M': gdp,
        'MHI_2023': mhi,
        'Top_3_Cities': top_cities,
    })

df = pd.DataFrame(rows)
print(f"States: {len(df)}")

# ============================================================
# Priority Scoring (0-100)
# ============================================================
# Weights:
# Population:           20 pts (log scale)
# Major cities count:   15 pts  
# GDP:                  15 pts (log scale)
# MHI / wealth:         10 pts
# Professional services: 15 pts (custom assessment)
# Digital adoption:      10 pts
# Target market fit:     15 pts (custom for goldfindesk ICP)

# Professional services strength (custom, based on industry knowledge)
PROF_SERVICES = {
    'California': 10, 'New York': 10, 'Texas': 9, 'Florida': 8, 'Illinois': 8,
    'Massachusetts': 10, 'Washington': 9, 'Virginia': 8, 'New Jersey': 8, 'Georgia': 8,
    'Colorado': 8, 'Pennsylvania': 7, 'North Carolina': 8, 'Maryland': 8, 'Connecticut': 8,
    'Minnesota': 7, 'Oregon': 7, 'Arizona': 7, 'Tennessee': 7, 'Ohio': 6,
    'Michigan': 6, 'Missouri': 6, 'Wisconsin': 6, 'Indiana': 5, 'Nevada': 7,
    'Utah': 8, 'South Carolina': 6, 'Alabama': 5, 'Kentucky': 5, 'Louisiana': 5,
    'Oklahoma': 5, 'Iowa': 5, 'Kansas': 5, 'Nebraska': 5, 'Arkansas': 4,
    'Mississippi': 4, 'New Mexico': 5, 'Hawaii': 6, 'Idaho': 6, 'New Hampshire': 7,
    'Maine': 5, 'Rhode Island': 6, 'Delaware': 7, 'Montana': 5, 'Vermont': 5,
    'South Dakota': 5, 'North Dakota': 5, 'West Virginia': 4, 'Wyoming': 4, 'Alaska': 5,
}

# Digital adoption / tech-savvy (proxy: tech sector strength + internet adoption)
DIGITAL = {
    'California': 10, 'Washington': 10, 'Massachusetts': 10, 'New York': 9, 'Colorado': 9,
    'Texas': 8, 'Virginia': 8, 'Utah': 9, 'Oregon': 8, 'Illinois': 7,
    'Georgia': 7, 'North Carolina': 8, 'Minnesota': 7, 'New Jersey': 7, 'Connecticut': 7,
    'Maryland': 7, 'Pennsylvania': 6, 'Arizona': 7, 'Tennessee': 6, 'Florida': 7,
    'Michigan': 6, 'Ohio': 6, 'Wisconsin': 6, 'Nevada': 7, 'New Hampshire': 7,
    'Idaho': 7, 'Indiana': 5, 'Missouri': 5, 'South Carolina': 5, 'Iowa': 5,
    'Nebraska': 5, 'Kansas': 5, 'Oklahoma': 5, 'Kentucky': 5, 'Alabama': 5,
    'Louisiana': 5, 'Hawaii': 6, 'Rhode Island': 6, 'Delaware': 6, 'Maine': 5,
    'Arkansas': 4, 'Mississippi': 4, 'New Mexico': 5, 'Montana': 5, 'Vermont': 6,
    'South Dakota': 5, 'North Dakota': 5, 'West Virginia': 4, 'Wyoming': 5, 'Alaska': 5,
}

# GoldFinDesk target market fit (agencies, consultants, clinics, restaurants, trades, e-commerce)
TARGET_FIT = {
    'California': 10, 'New York': 10, 'Texas': 9, 'Florida': 9, 'Illinois': 8,
    'Massachusetts': 9, 'Washington': 9, 'Georgia': 8, 'Colorado': 8, 'Virginia': 8,
    'New Jersey': 8, 'North Carolina': 8, 'Pennsylvania': 7, 'Arizona': 7, 'Tennessee': 7,
    'Maryland': 7, 'Connecticut': 7, 'Minnesota': 7, 'Oregon': 7, 'Ohio': 6,
    'Michigan': 6, 'Nevada': 7, 'Utah': 8, 'South Carolina': 6, 'Indiana': 5,
    'Missouri': 6, 'Wisconsin': 6, 'Alabama': 5, 'Kentucky': 5, 'Louisiana': 5,
    'Oklahoma': 5, 'Iowa': 5, 'Kansas': 5, 'Nebraska': 5, 'Hawaii': 6,
    'Idaho': 6, 'New Hampshire': 7, 'Arkansas': 4, 'Mississippi': 4, 'New Mexico': 5,
    'Delaware': 6, 'Rhode Island': 6, 'Maine': 5, 'Montana': 5, 'Vermont': 5,
    'South Dakota': 5, 'North Dakota': 5, 'West Virginia': 4, 'Wyoming': 4, 'Alaska': 5,
}

# No-income-tax bonus
NO_TAX = {'TX': 2, 'FL': 2, 'NV': 2, 'WA': 2, 'TN': 1, 'WY': 1, 'SD': 1, 'NH': 1, 'AK': 1}

max_pop = df['Pop_2020'].max()
max_gdp = df['GDP_2024_M'].max()
max_mhi = df['MHI_2023'].max()
max_cities = df['Major_Cities'].max()

def compute_score(row):
    # 1. Population (20 pts)
    pop_score = min(20, (math.log10(max(row['Pop_2020'], 1)) / math.log10(max_pop)) * 20)
    
    # 2. Major cities (15 pts)
    city_score = min(15, (row['Major_Cities'] / max_cities) * 15) if max_cities > 0 else 0
    
    # 3. GDP (15 pts)
    gdp_score = min(15, (math.log10(max(row['GDP_2024_M'], 1)) / math.log10(max_gdp)) * 15) if row['GDP_2024_M'] > 0 else 0
    
    # 4. MHI / Wealth (10 pts)
    mhi_score = min(10, (row['MHI_2023'] / max_mhi) * 10)
    
    # 5. Professional services (15 pts)
    prof_score = min(15, PROF_SERVICES.get(row['State'], 5) * 1.5)
    
    # 6. Digital adoption (10 pts)
    digi_score = min(10, DIGITAL.get(row['State'], 5))
    
    # 7. Target market fit (15 pts)
    target_score = min(15, TARGET_FIT.get(row['State'], 5) * 1.5)
    
    # No-tax bonus (up to 2 pts added to total)
    tax_bonus = NO_TAX.get(row['State_Code'], 0)
    
    total = pop_score + city_score + gdp_score + mhi_score + prof_score + digi_score + target_score + tax_bonus
    return round(min(100, total), 1)

df['Priority_Score'] = df.apply(compute_score, axis=1)
df = df.sort_values('Priority_Score', ascending=False).reset_index(drop=True)
df['Rank'] = range(1, 51)

# Add tracking columns
df['Status'] = 'Not Started'
df['Date_Started'] = ''
df['Date_Completed'] = ''
df['Notes'] = ''

print("\nFinal Rankings:")
print(df[['Rank', 'State', 'State_Code', 'Pop_2020', 'Major_Cities', 'GDP_2024_M', 'MHI_2023', 'Priority_Score']].to_string())

# ============================================================
# Build Excel
# ============================================================
DARK_BLUE = PatternFill(start_color='1F4E79', end_color='1F4E79', fill_type='solid')
MED_BLUE = PatternFill(start_color='2E75B6', end_color='2E75B6', fill_type='solid')
LIGHT_BLUE = PatternFill(start_color='D6E4F0', end_color='D6E4F0', fill_type='solid')
GREEN_FILL = PatternFill(start_color='C6EFCE', end_color='C6EFCE', fill_type='solid')
YELLOW_FILL = PatternFill(start_color='FFF2CC', end_color='FFF2CC', fill_type='solid')
RED_FILL = PatternFill(start_color='F2DCDB', end_color='F2DCDB', fill_type='solid')

HEADER_FONT = Font(name='Arial', size=11, bold=True, color='FFFFFF')
TITLE_FONT = Font(name='Arial', size=16, bold=True, color='1F4E79')
SUBTITLE_FONT = Font(name='Arial', size=11, color='666666')
SECTION_FONT = Font(name='Arial', size=12, bold=True, color='1F4E79')
COL_HEADER_FONT = Font(name='Arial', size=10, bold=True)
DATA_FONT = Font(name='Arial', size=10)
BOLD_FONT = Font(name='Arial', size=10, bold=True)
METRIC_FONT = Font(name='Arial', size=20, bold=True, color='1F4E79')

HEADER_ALIGN = Alignment(horizontal='center', vertical='center', wrap_text=True)
CENTER_ALIGN = Alignment(horizontal='center', vertical='center')
LEFT_ALIGN = Alignment(horizontal='left', vertical='center')
NUM_ALIGN = Alignment(horizontal='right', vertical='center')

THIN_BORDER = Border(
    left=Side(style='thin', color='B4C6E7'),
    right=Side(style='thin', color='B4C6E7'),
    top=Side(style='thin', color='B4C6E7'),
    bottom=Side(style='thin', color='B4C6E7'),
)

wb = openpyxl.Workbook()

# ============================================================
# DASHBOARD Sheet
# ============================================================
ws = wb.active
ws.title = 'DASHBOARD'

# Title block
ws.merge_cells('A1:N1')
c = ws.cell(1, 1)
c.value = 'US STATES SEO MASTER TRACKER — goldfindesk.com'
c.font = TITLE_FONT
c.alignment = Alignment(horizontal='left', vertical='center')
ws.row_dimensions[1].height = 40

ws.merge_cells('A2:N2')
c = ws.cell(2, 1)
c.value = f'All 50 US States Ranked for SEO & AI SEO Database Expansion | Updated: {today_str}'
c.font = SUBTITLE_FONT

# --- PROGRESS SUMMARY ---
row = 4
ws.merge_cells(f'A{row}:D{row}')
c = ws.cell(row, 1); c.value = 'PROGRESS SUMMARY'; c.font = SECTION_FONT
for ci in range(1, 5):
    ws.cell(row, ci).fill = LIGHT_BLUE

row = 5
metrics = [
    ('Total States', 50),
    ('Completed', 0),
    ('In Progress', 0),
    ('Not Started', 50),
]
for i, (label, val) in enumerate(metrics):
    col = i * 2 + 1
    ws.cell(row, col).value = label
    ws.cell(row, col).font = BOLD_FONT
    ws.cell(row, col + 1).value = val
    ws.cell(row, col + 1).font = METRIC_FONT
    ws.cell(row, col + 1).alignment = CENTER_ALIGN

# --- PRIORITY TIERS ---
row = 8
ws.merge_cells(f'A{row}:F{row}')
c = ws.cell(row, 1); c.value = 'PRIORITY TIERS'; c.font = SECTION_FONT
for ci in range(1, 7):
    ws.cell(row, ci).fill = LIGHT_BLUE

tier_headers = ['Tier', 'Score Range', 'States', 'Description', 'Strategy', 'Example States']
row = 9
for ci, h in enumerate(tier_headers, 1):
    c = ws.cell(row, ci); c.value = h; c.font = COL_HEADER_FONT; c.fill = LIGHT_BLUE; c.border = THIN_BORDER

tier1 = df[df['Rank'] <= 10]
tier2 = df[(df['Rank'] > 10) & (df['Rank'] <= 25)]
tier3 = df[df['Rank'] > 25]

tiers = [
    ('Tier 1', f"{tier1['Priority_Score'].min():.0f}–{tier1['Priority_Score'].max():.0f}", 10,
     'Top priority — largest, wealthiest markets with highest business density',
     'Build 200-500+ location databases first',
     ', '.join(tier1.head(5)['State_Code'].values)),
    ('Tier 2', f"{tier2['Priority_Score'].min():.0f}–{tier2['Priority_Score'].max():.0f}", 15,
     'Strong markets — significant economies with solid professional services',
     'Build after Tier 1 completion',
     ', '.join(tier2.head(5)['State_Code'].values)),
    ('Tier 3', f"{tier3['Priority_Score'].min():.0f}–{tier3['Priority_Score'].max():.0f}", 25,
     'Smaller markets — build when major states are complete',
     'Lower volume but less competition',
     ', '.join(tier3.head(5)['State_Code'].values)),
]

for i, (name, rng, count, desc, strat, examples) in enumerate(tiers):
    r = row + 1 + i
    vals = [name, rng, count, desc, strat, examples]
    fills = [GREEN_FILL, YELLOW_FILL, RED_FILL]
    for ci, v in enumerate(vals, 1):
        c = ws.cell(r, ci); c.value = v; c.font = DATA_FONT; c.border = THIN_BORDER
    ws.cell(r, 1).fill = fills[i]
    ws.cell(r, 1).font = BOLD_FONT

# --- REGIONAL BREAKDOWN ---
row = 14
ws.merge_cells(f'A{row}:F{row}')
c = ws.cell(row, 1); c.value = 'REGIONAL BREAKDOWN'; c.font = SECTION_FONT
for ci in range(1, 7):
    ws.cell(row, ci).fill = LIGHT_BLUE

reg_headers = ['Region', 'States', 'Total Population', 'Avg Priority Score', 'Top State', 'Avg MHI']
row = 15
for ci, h in enumerate(reg_headers, 1):
    c = ws.cell(row, ci); c.value = h; c.font = COL_HEADER_FONT; c.fill = LIGHT_BLUE; c.border = THIN_BORDER

for region in ['Northeast', 'South', 'Midwest', 'West']:
    row += 1
    reg_df = df[df['Region'] == region]
    top_state = reg_df.sort_values('Priority_Score', ascending=False).iloc[0]
    vals = [
        region,
        len(reg_df),
        reg_df['Pop_2020'].sum(),
        round(reg_df['Priority_Score'].mean(), 1),
        f"{top_state['State']} ({top_state['Priority_Score']})",
        f"${reg_df['MHI_2023'].mean():,.0f}",
    ]
    for ci, v in enumerate(vals, 1):
        c = ws.cell(row, ci); c.value = v; c.font = DATA_FONT; c.border = THIN_BORDER
        if ci == 3 and isinstance(v, (int, float)):
            c.number_format = '#,##0'

# --- TOP 10 QUICK VIEW ---
row += 2
ws.merge_cells(f'A{row}:F{row}')
c = ws.cell(row, 1); c.value = 'TOP 10 STATES — BUILD FIRST'; c.font = SECTION_FONT
for ci in range(1, 7):
    ws.cell(row, ci).fill = LIGHT_BLUE

row += 1
quick_headers = ['Rank', 'State', 'Code', 'Population', 'Major Cities', 'Score']
for ci, h in enumerate(quick_headers, 1):
    c = ws.cell(row, ci); c.value = h; c.font = COL_HEADER_FONT; c.fill = LIGHT_BLUE; c.border = THIN_BORDER

for _, srow in df.head(10).iterrows():
    row += 1
    vals = [srow['Rank'], srow['State'], srow['State_Code'], srow['Pop_2020'], srow['Major_Cities'], srow['Priority_Score']]
    for ci, v in enumerate(vals, 1):
        c = ws.cell(row, ci); c.value = v; c.font = DATA_FONT; c.border = THIN_BORDER
        if ci == 4: c.number_format = '#,##0'
        if ci in (1, 3, 5, 6): c.alignment = CENTER_ALIGN

# --- GOLDFINDESK TARGET MARKET ---
row += 2
ws.merge_cells(f'A{row}:F{row}')
c = ws.cell(row, 1); c.value = 'GOLDFINDESK TARGET MARKET PROFILE'; c.font = SECTION_FONT
for ci in range(1, 7):
    ws.cell(row, ci).fill = LIGHT_BLUE

target_info = [
    ['Service', 'B2B financial clarity for owner-led businesses'],
    ['Revenue Sweet Spot', '$50K–$500K/month (5–50 employees)'],
    ['Pricing', '$99/month → requires HIGH VOLUME markets'],
    ['Target Verticals', 'Agencies, Consultants, Professional Firms, Clinics, Restaurants, Trades, E-commerce, Local Services'],
    ['Ideal Market', 'Dense concentration of owner-led businesses that have outgrown DIY spreadsheets but aren\'t ready for a full-time CFO'],
    ['Best States', 'Large population + high MHI + strong professional services + many major cities'],
]
for info in target_info:
    row += 1
    ws.cell(row, 1).value = info[0]; ws.cell(row, 1).font = BOLD_FONT
    ws.merge_cells(f'B{row}:F{row}')
    ws.cell(row, 2).value = info[1]; ws.cell(row, 2).font = DATA_FONT

# Dashboard column widths
for col, w in {'A': 22, 'B': 16, 'C': 18, 'D': 55, 'E': 38, 'F': 30, 'G': 12, 'H': 12}.items():
    ws.column_dimensions[col].width = w

# ============================================================
# STATE TRACKER Sheet
# ============================================================
ws2 = wb.create_sheet('STATE_TRACKER')

# Title
ws2.merge_cells('A1:M1')
c = ws2.cell(1, 1)
c.value = 'US STATES — COMPLETE RANKING & TRACKING'
c.font = HEADER_FONT; c.fill = DARK_BLUE; c.alignment = HEADER_ALIGN
ws2.row_dimensions[1].height = 30
for ci in range(1, 14):
    ws2.cell(1, ci).fill = DARK_BLUE

# Column headers
col_names = ['Rank', 'State Name', 'State Code', 'Region', 'Population (2020 Census)',
             'Major Cities (100K+)', 'GDP 2024 ($M)', 'Median Household Income',
             'Priority Score', 'Top 3 Cities', 'Status', 'Date Started', 'Date Completed']
col_widths = [8, 20, 10, 14, 20, 18, 18, 22, 14, 38, 14, 14, 16]

for i, cn in enumerate(col_names, 1):
    c = ws2.cell(2, i); c.value = cn; c.font = COL_HEADER_FONT; c.fill = LIGHT_BLUE
    c.alignment = HEADER_ALIGN; c.border = THIN_BORDER

for i, w in enumerate(col_widths):
    ws2.column_dimensions[get_column_letter(i+1)].width = w

# Data validation for Status
from openpyxl.worksheet.datavalidation import DataValidation
dv = DataValidation(type='list', formula1='"Not Started,In Progress,Complete"', allow_blank=True)
dv.error = 'Select: Not Started, In Progress, or Complete'
ws2.add_data_validation(dv)

# Write data
for idx, row_data in df.iterrows():
    r = idx + 3
    values = [
        row_data['Rank'], row_data['State'], row_data['State_Code'], row_data['Region'],
        int(row_data['Pop_2020']), int(row_data['Major_Cities']),
        round(row_data['GDP_2024_M']), int(row_data['MHI_2023']),
        row_data['Priority_Score'], row_data['Top_3_Cities'],
        row_data['Status'], row_data['Date_Started'], row_data['Date_Completed'],
    ]
    for ci, val in enumerate(values, 1):
        c = ws2.cell(r, ci)
        c.value = val
        c.font = DATA_FONT
        c.border = THIN_BORDER
        
        if ci in (1, 3, 6, 9, 11):  # centered cols
            c.alignment = CENTER_ALIGN
        elif ci in (5, 7, 8):  # number cols
            c.alignment = NUM_ALIGN
            if ci == 5: c.number_format = '#,##0'
            elif ci == 7: c.number_format = '#,##0'
            elif ci == 8: c.number_format = '$#,##0'
        elif ci == 9:
            c.number_format = '0.0'
        else:
            c.alignment = LEFT_ALIGN
    
    # Apply status dropdown
    dv.add(ws2.cell(r, 11))

# Conditional formatting on Priority Score
ws2.conditional_formatting.add(f'I3:I52',
    CellIsRule(operator='greaterThanOrEqual', formula=['70'], fill=PatternFill(bgColor='C6EFCE')))
ws2.conditional_formatting.add(f'I3:I52',
    CellIsRule(operator='between', formula=['55', '69.9'], fill=PatternFill(bgColor='FFF2CC')))
ws2.conditional_formatting.add(f'I3:I52',
    CellIsRule(operator='lessThan', formula=['55'], fill=PatternFill(bgColor='F2DCDB')))

# Freeze + filter
ws2.freeze_panes = 'A3'
ws2.auto_filter.ref = f'A2:M52'

# ============================================================
# SCORING_METHODOLOGY Sheet
# ============================================================
ws3 = wb.create_sheet('SCORING_METHODOLOGY')

scoring_content = [
    ['STATE SEO PRIORITY SCORING METHODOLOGY'],
    [f'For goldfindesk.com | Updated: {today_str} | 50 States Ranked'],
    [''],
    ['SCORING COMPONENTS', 'Max Points', 'Data Source', 'Methodology'],
    ['1. Total Population', 20, 'U.S. Census Bureau 2020', 'Logarithmic scale normalized to most populous state (CA: 39.5M)'],
    ['2. Number of Major Cities (100K+)', 15, 'Census Sub-County Estimates 2020', 'Linear scale: more major cities = more SEO location pages possible'],
    ['3. GDP (Economic Strength)', 15, 'Bureau of Economic Analysis 2024', 'Logarithmic scale: larger economy = more business activity'],
    ['4. Median Household Income', 10, 'ACS 2023 1-Year Estimates', 'Linear scale: higher income = more businesses in GoldFin sweet spot'],
    ['5. Professional Services Concentration', 15, 'Industry analysis (agencies, consultants, firms)', 'Expert-rated 1-10 scale × 1.5: density of target verticals'],
    ['6. Digital Adoption / Tech-Savvy', 10, 'Tech sector employment, broadband adoption', 'Expert-rated 1-10: likelihood of online search for financial services'],
    ['7. Target Market Fit (GoldFinDesk ICP)', 15, 'Business demographics, vertical analysis', 'Expert-rated 1-10 × 1.5: alignment with owner-led business verticals'],
    ['Bonus: No-Income-Tax State', 2, 'State tax policy', 'TX, FL, NV, WA = +2; TN, WY, SD, NH, AK = +1'],
    ['TOTAL', 102, '', 'Capped at 100'],
    [''],
    ['WHAT MAKES A STATE HIGH-PRIORITY FOR GOLDFINDESK?'],
    [''],
    ['1. Large, urban population with many major cities (more neighborhoods = more SEO pages)'],
    ['2. Strong professional services sector (agencies, consultants, accountants, lawyers)'],
    ['3. High median household income (businesses in the $50K-$500K/month sweet spot)'],
    ['4. Business-friendly environment (no income tax states attract entrepreneurs)'],
    ['5. Tech-savvy demographics (business owners who search online for financial services)'],
    ['6. Dense concentration of GoldFin target verticals (restaurants, clinics, trades, e-commerce)'],
    [''],
    ['DATA SOURCES'],
    [''],
    ['• U.S. Census Bureau — 2020 Decennial Census (state and city populations)'],
    ['• U.S. Census Bureau — Sub-County Population Estimates (ESTIMATESBASE2020)'],
    ['• Bureau of Economic Analysis — GDP by State, 2024 annual data'],
    ['• American Community Survey (ACS) — 2023 1-Year Estimates (median household income)'],
    ['• State tax policy analysis (no-income-tax status)'],
    ['• Industry composition data (professional services concentration assessment)'],
    [''],
    ['HOW TO USE THIS TRACKER'],
    [''],
    ['1. Sort STATE_TRACKER by Priority Score (column I) to see which states to build next'],
    ['2. Update Status to "In Progress" when beginning a state\'s city-level SEO databases'],
    ['3. Each state database should cover major cities with 200-500+ location entries per city'],
    ['4. Mark "Complete" when all major cities in a state have been built'],
    ['5. Tier 1 states should be completed first — they represent 60%+ of the addressable market'],
    ['6. Within each state, prioritize cities using the US Cities SEO Tracker (us_cities_seo_master_tracker.xlsx)'],
]

for r_idx, row_data in enumerate(scoring_content, 1):
    for c_idx, val in enumerate(row_data, 1):
        c = ws3.cell(r_idx, c_idx); c.value = val
        if r_idx == 1:
            c.font = Font(name='Arial', size=14, bold=True, color='1F4E79')
        elif r_idx == 2:
            c.font = SUBTITLE_FONT
        elif r_idx == 4:
            c.font = COL_HEADER_FONT; c.fill = LIGHT_BLUE
        elif isinstance(val, str) and (val.startswith('1.') or val.startswith('2.') or val.startswith('3.') or val.startswith('4.') or val.startswith('5.') or val.startswith('6.') or val.startswith('7.') or val.startswith('Bonus')):
            c.font = BOLD_FONT
        elif isinstance(val, str) and val.isupper() and len(val) > 5:
            c.font = SECTION_FONT
        else:
            c.font = DATA_FONT

ws3.column_dimensions['A'].width = 45
ws3.column_dimensions['B'].width = 14
ws3.column_dimensions['C'].width = 45
ws3.column_dimensions['D'].width = 70

# ============================================================
# Save
# ============================================================
output = '/home/ubuntu/us_states_seo_master_tracker.xlsx'
wb.save(output)
print(f"\nSaved to {output}")
print(f"Sheets: {wb.sheetnames}")
print(f"States: {len(df)}")
